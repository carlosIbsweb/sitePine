<?php
/**
 * @version     1.0.0
 * @package     com_s7dpayments
 * @copyright   Copyright (C) 2016. Todos os direitos reservados.
 * @license     GNU General Public License versão 2 ou posterior; consulte o arquivo License. txt
 */

?>


<div style="margin:0;padding: 40p;font-family:Arial,Helvetica,sans-serif;background-color:#dfdfd7;">
<table background="#m_-6893885986876944149_F09967" border="0" cellpadding="0" cellspacing="0" style="display:table;width:650px;margin:auto;background-color:#dfdfd7">
<tbody>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" style="display:table;width:420px;margin:auto">
<tbody>
<tr>
<td>
<p style="text-transform:uppercase;color: #be35fe;text-align:center;font-weight:bold;font-size:36px;line-height:36px;padding:70px 0px 20px;margin:0;">Olá {nome}!!!</p>
</td>
</tr>
<tr>
<td>
<p style="color:#292b2d;font-size:18px;line-height:26px;text-align:center;margin:0 0 30px">A PINE se alegra com sua inscrição,<br> será uma experiência incrível para nós e para você. <br><strong>Seja bem-vindo(a) a Colônia de Férias<br> Pine Tree Farm.</strong></p>
</td>
</tr>



</tbody>
</table>
</td>
</tr>


</tbody>
</table><div class="yj6qo"></div><div class="adL">
</div></div>