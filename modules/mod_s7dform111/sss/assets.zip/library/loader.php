
<?php

/**
 * @package     
 * @subpackage  mod AwForm
 **/

// No direct access.
defined('_JEXEC') or die;

/********
 Classe Aw Captcha.
 Desenvolvido por Carlos (IBS WEB)
********/
